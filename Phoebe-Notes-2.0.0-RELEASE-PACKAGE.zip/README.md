# Phoebe-Notes

Download Here: https://chrome.google.com/webstore/detail/phoebe-notes/hoikdhcpdlhbhfgmcpdhdhbkjhenncje

![img1](https://user-images.githubusercontent.com/67698238/145685557-f2117562-5724-42fa-ad1a-6ac04a8c6fd0.jpg)
![img4](https://user-images.githubusercontent.com/67698238/145685558-a887dde1-c237-4a91-aa45-84b590d8f276.jpg)
![img3](https://user-images.githubusercontent.com/67698238/145685564-156bb349-4180-495e-babe-ea95e55248c3.jpg)
![img5](https://user-images.githubusercontent.com/67698238/145685565-fe81a3e5-d247-478c-bcc9-b0ce5ac2c07e.jpg)
![img2](https://user-images.githubusercontent.com/67698238/145685569-00fadd11-f055-4f26-ba79-8f406efc1a86.jpg)
